import React from 'react'

function ViewReport() {
  return (
    <div className="bg-gradient-to-b from-[#FFFFFF] to-[#E5DCDA] pb-16 min-h-screen">ViewReport</div>
  )
}

export default ViewReport